import React, { useState } from 'react';
import { SessionStats, AnalysisMode } from '../types';
import { FileText, Download, Bot, Loader2, Printer, Sparkles } from 'lucide-react';

interface SessionReportProps { stats: SessionStats; analysisMode: AnalysisMode; onResetSession: () => void; }

export const SessionReport: React.FC<SessionReportProps> = ({ stats, analysisMode }) => {
  const [aiReport, setAiReport] = useState<string | null>(null);
  const [isLoadingAi, setIsLoadingAi] = useState(false);
  const [aiError, setAiError] = useState<string | null>(null);
  const isKnee = analysisMode === 'knee';

  const handleGenerateAiFeedback = async () => {
    setIsLoadingAi(true); setAiError(null);
    try {
      const response = await fetch('/api/rehab-feedback', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({
        mode: analysisMode, durationSec: stats.durationSec, asymmetry: stats.avgAsymmetry,
        leftMaxFlexion: stats.leftMaxFlexion, rightMaxFlexion: stats.rightMaxFlexion, leftMinExtension: stats.leftMinExtension, rightMinExtension: stats.rightMinExtension,
        stiffKneeCount: stats.stiffKneeCount, totalGaitCycles: stats.totalGaitCycles, avgSwingFlexionLeft: stats.avgSwingFlexionLeft, avgSwingFlexionRight: stats.avgSwingFlexionRight, repCount: stats.kneeRepCount,
        leftMaxShoulderROM: stats.leftMaxShoulderROM, rightMaxShoulderROM: stats.rightMaxShoulderROM, shoulderRepCount: stats.shoulderRepCount, compensationCount: stats.compensationCount,
      }) });
      const data = await response.json();
      if (!response.ok || data.error) setAiError(data.error || 'AI 분석 리포트를 불러오지 못했습니다.'); else setAiReport(data.report);
    } catch { setAiError('AI 분석 리포트를 불러오는 중 오류가 발생했습니다.'); } finally { setIsLoadingAi(false); }
  };

  const handleExportCSV = () => {
    if (!stats.history.length) return;
    const headers = ['Timestamp(s)', 'LeftAngle(deg)', 'RightAngle(deg)', 'Asymmetry(deg)', 'GaitPhase', 'StiffKneeEvent', 'Compensation'];
    const rows = stats.history.map((pt) => [pt.time.toFixed(2), pt.leftAngle.toFixed(1), pt.rightAngle.toFixed(1), pt.asymmetry.toFixed(1), pt.gaitPhase || '', pt.isStiffKneeEvent ? 'YES' : 'NO', pt.isCompensated ? 'YES' : 'NO']);
    const blob = new Blob([[headers.join(','), ...rows.map((row) => row.join(','))].join('\n')], { type: 'text/csv;charset=utf-8' });
    const url = URL.createObjectURL(blob); const link = document.createElement('a'); link.href = url; link.download = `Rehab_Session_${new Date().toISOString().slice(0, 10)}.csv`; link.click(); URL.revokeObjectURL(url);
  };

  const metrics = isKnee ? [
    ['좌측 최대 굴곡', `${stats.leftMaxFlexion.toFixed(1)}°`, `최소 신전 ${stats.leftMinExtension.toFixed(1)}°`], ['우측 최대 굴곡', `${stats.rightMaxFlexion.toFixed(1)}°`, `최소 신전 ${stats.rightMinExtension.toFixed(1)}°`],
    ['유각기 평균 굴곡', `${Math.max(stats.avgSwingFlexionLeft, stats.avgSwingFlexionRight).toFixed(1)}°`, `좌 ${stats.avgSwingFlexionLeft.toFixed(1)}° · 우 ${stats.avgSwingFlexionRight.toFixed(1)}°`], ['보행 추정 이벤트', `${stats.totalGaitCycles}회`, `Stiff Knee 추정 ${stats.stiffKneeCount}회`],
  ] : [
    ['좌측 최대 ROM', `${stats.leftMaxShoulderROM.toFixed(1)}°`, '웹캠 기반 추정값'], ['우측 최대 ROM', `${stats.rightMaxShoulderROM.toFixed(1)}°`, '웹캠 기반 추정값'],
    ['좌우 비대칭', `${stats.avgAsymmetry.toFixed(1)}°`, `최대 ${stats.maxAsymmetry.toFixed(1)}°`], ['운동·보상 기록', `${stats.shoulderRepCount}회`, `몸통 보상 ${stats.compensationCount}프레임`],
  ];

  return <div className="bg-white border border-[#DEDECF] rounded-[28px] p-6 shadow-sm space-y-6">
    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[#F0F0E8] pb-4"><div><div className="flex items-center gap-2"><FileText className="w-6 h-6 text-[#FF6321]" /><h2 className="text-xl font-bold">세션 분석 리포트</h2></div><p className="text-xs text-[#8A8A70] mt-1">측정 시간 {stats.durationSec}초 · 기록 프레임 {stats.totalFramesAnalyzed}</p></div><div className="flex gap-2 print:hidden"><button onClick={handleExportCSV} className="px-4 py-2.5 rounded-2xl bg-[#F5F5F0] text-xs font-semibold border border-[#DEDECF] flex gap-1.5"><Download className="w-4 h-4" />CSV 다운로드</button><button onClick={() => window.print()} className="px-4 py-2.5 rounded-2xl bg-[#5A5A40] text-white text-xs font-semibold flex gap-1.5"><Printer className="w-4 h-4" />인쇄/PDF</button></div></div>
    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">{metrics.map(([label, value, note]) => <div key={label} className="bg-[#FDFDFB] p-4 rounded-2xl border border-[#F0F0E8]"><span className="text-[10px] font-bold text-[#8A8A70] block">{label}</span><span className="block mt-2 text-3xl font-serif font-black text-[#FF6321]">{value}</span><span className="block mt-2 text-[11px] text-[#5A5A40]">{note}</span></div>)}</div>
    <p className="text-[11px] text-[#8A8A70]">보행 이벤트와 관절각은 단일 웹캠 MediaPipe 기반 추정값이며, 의료 진단 또는 임상 보행검사 결과를 대체하지 않습니다.</p>
    <div className="bg-[#5A5A40] rounded-2xl p-5 text-white space-y-4"><div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3"><div className="flex gap-2.5"><Bot className="w-6 h-6" /><div><h3 className="text-sm font-bold">Gemini AI 세션 피드백</h3><p className="text-xs opacity-80">현재 세션 데이터만 전송해 요약합니다.</p></div></div><button onClick={handleGenerateAiFeedback} disabled={isLoadingAi} className="px-4 py-2.5 rounded-2xl bg-[#FF6321] text-xs font-semibold flex gap-2 disabled:opacity-50">{isLoadingAi ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}{isLoadingAi ? '생성 중...' : 'AI 보고서 생성'}</button></div>{aiError && <p className="p-3 bg-red-500/20 rounded-xl text-xs">{aiError}</p>}{aiReport && <div className="p-4 bg-white text-[#2D2D24] rounded-2xl text-sm whitespace-pre-wrap">{aiReport}</div>}</div>
  </div>;
};
